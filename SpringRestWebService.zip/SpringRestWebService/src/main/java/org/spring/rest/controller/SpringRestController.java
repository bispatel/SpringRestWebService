package org.spring.rest.controller;

import java.util.ArrayList;
import java.util.List;

import org.spring.rest.domain.Employee;
import org.spring.rest.domain.EmployeeList;
import org.springframework.http.MediaType;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

@RestController
@RequestMapping("/employees")
public class SpringRestController {

	@RequestMapping(value = "json/all", method = RequestMethod.GET, produces = MediaType.APPLICATION_JSON_VALUE)
	public Object getEmployees() {
		EmployeeList listOfCountries = createEmpList();
		return listOfCountries;
	}

	@RequestMapping(value = "json/{id}", method = RequestMethod.GET, produces = MediaType.APPLICATION_JSON_VALUE)
	public Employee getEmpId(@PathVariable int id) {
		EmployeeList listOfCountries = createEmpList();
		for (Employee emp : listOfCountries.getEmpList()) {
			if (emp.getEmpId() == id)
				return emp;
		}
		return null;
	}

	@RequestMapping(value = "xml/all", method = RequestMethod.GET, produces = MediaType.APPLICATION_XML_VALUE)
	public Object getAllEmployee() {
		EmployeeList listOfCountries = createEmpList();
		return listOfCountries;
	}

	@RequestMapping(value = "xml/{id}", method = RequestMethod.GET, produces = MediaType.APPLICATION_XML_VALUE)
	public Employee getEmployee(@PathVariable int id) {
		EmployeeList listOfCountries = createEmpList();
		for (Employee emp : listOfCountries.getEmpList()) {
			if (emp.getEmpId() == id)
				return emp;
		}
		return null;
	}

	public EmployeeList createEmpList() {
		Employee emp1 = new Employee(1, "Bishwajit", 30);
		Employee emp2 = new Employee(2, "Ponvel", 34);
		Employee emp3 = new Employee(3, "Vinjam", 28);
		Employee emp4 = new Employee(2, "Abhisekh", 34);

		List<Employee> empList = new ArrayList<>();
		empList.add(emp1);
		empList.add(emp2);
		empList.add(emp3);
		empList.add(emp4);
		return new EmployeeList(empList);
	}
}