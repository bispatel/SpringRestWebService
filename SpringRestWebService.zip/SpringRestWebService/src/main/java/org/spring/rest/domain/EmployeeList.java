package org.spring.rest.domain;

import java.util.List;

import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlRootElement;

@XmlRootElement(name = "employee-list")
public class EmployeeList {

	List<Employee> empList;

	public EmployeeList() {
		super();
	}

	public EmployeeList(List<Employee> empList) {
		this.empList = empList;
	}

	public List<Employee> getEmpList() {
		return empList;
	}

	@XmlElement(name = "employee")
	public void setEmpList(List<Employee> empList) {
		this.empList = empList;
	}

}
